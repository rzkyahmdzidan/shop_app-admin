const { Sequelize } = require("sequelize");

const db = new Sequelize('shop-app', 'root', '', {
    host: 'localhost',
    dialect: 'mysql'
})

module.exports = db;