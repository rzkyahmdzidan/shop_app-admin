const FavouritesModel = require("../models/favourites_model")

class FavouritesController {
  static byUser(req, res) {
    const idUser = req.idUser
    
    FavouritesModel.findAll({
      where: { idUser }
    })
      .then((data) => {
        res.status(200).json({
          status: true,
          message: "Berhasil mengambil data favourites",
          data: data,
        })
      })
      .catch((err) => {
        console.log(err)
        res.status(500).json({
          status: false,
          message: "Terjadi kesalahan, silahkan coba lagi",
          data: {},
        })
      })
  }

  static async addFavourites(req, res) {
    try {
      const idUser = req.idUser
      const { idProduk } = req.body

      const existing = await FavouritesModel.findOne({
        where: { idUser, idProduk }
      })
      if (existing) return

      FavouritesModel.create({ idUser, idProduk })
        .then((data) => {
          res.status(201).json({
            status: true,
            message: "Berhasil menambah data favourites",
            data: data,
          })
        })
    } catch (error) {
      console.log(error)
      res.status(500).json({
        status: false,
        message: "Terjadi kesalahan, silahkan coba lagi",
        data: {},
      })
    }
  }

  static removeFavourites(req, res) {
    const idUser = req.idUser
    const { idProduk } = req.params

    FavouritesModel.destroy({
      where: { idUser, idProduk }
    })
      .then((rows) => {
        res.status(200).json({
          status: true,
          message: "Berhasil menghapus data favourites",
          data: {},
        })
      })
      .catch((err) => {
        console.log(err)
        res.status(500).json({
          status: false,
          message: "Terjadi kesalahan, silahkan coba lagi",
          data: {},
        })
      })
  }
}

module.exports = FavouritesController