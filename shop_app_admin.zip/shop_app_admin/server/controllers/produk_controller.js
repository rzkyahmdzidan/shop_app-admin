const FavouritesModel = require("../models/favourites_model")
const ProdukModel = require("../models/produk_model")

class ProdukController {
  static async allProduk(req, res) {
    try {
      const idUser = req.idUser
      const favourites = await FavouritesModel.findAll({ where: { idUser } })

      ProdukModel.findAll()
        .then((listProduk) => {
          const data = listProduk.map((produk, index) => {
            const favouriteId = favourites.find(fav => fav.idProduk === produk.id)?.id
            return {...produk.get(), favouriteId}
          })
          res.status(200).json({
            status: true,
            message: "Berhasil mengambil data produk",
            data: data,
          })
        })
    } catch (error) {
      console.log(error)
      res.status(500).json({
        status: false,
        message: "Terjadi kesalahan, silahkan coba lagi",
        data: {},
      })
    }
  }
}

module.exports = ProdukController