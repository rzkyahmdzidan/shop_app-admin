const { DataTypes } = require("sequelize")
const sequelize = require("../config/database")
const UserModel = require("./users_model")
const ProdukModel = require("./produk_model")

const FavouritesModel = sequelize.define("favourites", {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },
  idUser: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  idProduk: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
}, {
  freezeTableName: true,
})

FavouritesModel.belongsTo(UserModel, { foreignKey: "idUser", onDelete: "CASCADE" })
FavouritesModel.belongsTo(ProdukModel, { foreignKey: "idProduk", onDelete: "CASCADE" })

module.exports = FavouritesModel