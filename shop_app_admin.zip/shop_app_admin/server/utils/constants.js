const secret = "shop-app"
const saltRounds = 12
const idKecamatanToko = "235" // Lhokseumawe
const beratPaket = 1000 // gram
const rajaOngkirKey = "edbdb41bd34ae51a9ed93e36a3a60312"

module.exports = {
  secret,
  saltRounds,
  idKecamatanToko,
  beratPaket,
  rajaOngkirKey,
}
