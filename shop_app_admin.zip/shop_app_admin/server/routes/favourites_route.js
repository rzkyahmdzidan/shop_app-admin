const express = require("express")
const router = express.Router()
const authentication = require("../middlewares/authentication")
const FavouritesController = require("../controllers/favourites_controller")

router.get("/", authentication, FavouritesController.byUser)
router.post("/", authentication, FavouritesController.addFavourites)
router.delete("/:idProduk", authentication, FavouritesController.removeFavourites)

module.exports = router