const express = require("express")
const router = express.Router()
const ProdukController = require("../controllers/produk_controller")
const authentication = require("../middlewares/authentication")

router.get("/", authentication, ProdukController.allProduk)

module.exports = router