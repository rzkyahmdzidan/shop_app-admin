<div id="navbar">
    <img src="./assets/logo.png" alt="logo" width="100">
    <ul>
        <li id="dashboard"><a href="./dashboard.php">Dashboard</a></li>
        <li id="orders"><a href="./orders.php">Transactions</a></li>
        <li id="users"><a href="./users.php">Customers</a></li>
        <li id="produk"><a href="./produk.php">Products</a></li>
    </ul>
</div>