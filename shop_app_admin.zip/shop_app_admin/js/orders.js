const sort = document.querySelector("#sort select")

sort.addEventListener("change", () => {
  location.href = `./orders.php?sort=${sort.value}`
})