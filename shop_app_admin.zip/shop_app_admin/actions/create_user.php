<?php

    include '../config.php';
    $db = new Dbh();
    $conn = $db->connect();
    $error = "";

    if (isset($_POST["submit"])) {
        $email = $_POST["email"];
        $nama = $_POST["nama"];
        $saldo = $_POST["saldo"];

        $sql = "INSERT INTO users (email, nama, saldo) VALUES ('$email', '$nama', $saldo)";
        $result = $conn->query($sql);

        if ($result) {
            header("Location: ../users.php");
        } else {
            $error = "Gagal menambah user";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop App</title>
    <link rel="stylesheet" href="../css/general.css">
    <link rel="stylesheet" href="../css/actions.css">
    <link rel="shortcut icon" href="../assets/logo.png" type="image/x-icon">
</head>
<body>
    <!-- nampilkan eror -->
    <p id="error"><?= $error ?></p>

    <!-- kotak hijau  -->
    <div id="container">

        <!-- judul halaman yy -->
        <h1>Create User</h1>
        <form id="login" action="" method="post">
            <input type="text" name="email" placeholder="Email" required>
            <input type="text" name="nama" placeholder="Nama" required>
            <input type="number" name="saldo" placeholder="Saldo" autocomplete="off" required>
        </form>
        <button form="login" name="submit">Create</button>
    </div>
</body>
</html>