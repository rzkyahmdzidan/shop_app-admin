<?php

    include '../config.php';
    $db = new Dbh();
    $conn = $db->connect();
    $error = "";

    if (isset($_GET["id"])) {
        $id = $_GET["id"];

        $sql = "SELECT * FROM produk WHERE id=$id";
        $result = $conn->query($sql);
        $produk = $result->fetch_assoc();

    } else {
        header("Location: ../produk.php");
    }

    if (isset($_POST["submit"])) {
        extract($_POST);

        if ($_FILES["gambar"]["size"] > 0) {
            $target_dir = "../uploads/";
            $prefix_file = time() . "-";
            $file_name = $prefix_file . basename($_FILES["gambar"]["name"]);
            $target_file = $target_dir . $file_name;
            $success = move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file);
        } else {
            $success =  true;
            $file_name = $produk["images"];
        }

        if ($success) {
            extract($_POST);
            $sql = "UPDATE produk SET title='$title', description='$description', price=$price, idKategori=$kategori, images='$file_name' WHERE id=$id";
            $result = $conn->query($sql);
    
            if ($result) {
                header("Location: ../produk.php");
            } else {
                $error = "Gagal mengupdate produk";
            }
        } else {
            $error = "Gagal mengupdate produk";
        }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop App</title>
    <link rel="stylesheet" href="../css/general.css">
    <link rel="stylesheet" href="../css/actions.css">
    <link rel="shortcut icon" href="../assets/logo.png" type="image/x-icon">
</head>
<body>
    <!-- nampilkan eror -->
    <p id="error"><?= $error ?></p>

    <!-- kotak hijau  -->
    <div id="container">

        <!-- judul halaman yy -->
        <h1>Create Product</h1>
        <form id="login" action="" method="post" enctype="multipart/form-data">
            <input type="text" name="title" placeholder="Title" value="<?= $produk["title"] ?>" required>
            <textarea name="description" id="description" placeholder="Description" rows="5" required><?= $produk["description"] ?></textarea>
            <input type="number" name="price" placeholder="Price" min="1000" step="1000" value="<?= $produk["price"] ?>" required>
            <select name="kategori" id="kategori" required>
                <option value="">--- Pilih Kategori ---</option>
                <?php
                
                $sql = "SELECT * FROM kategori";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    ?>
                    
                    <option value="<?= $row["id"] ?>" <?= $row["id"] == $produk["idKategori"] ? "selected" : "" ?>>
                        <?= $row["nama"] ?>
                    </option>
                    
                    <?php
                }
                
                ?>
            </select>
            <label for="gambar">Pilih gambar:</label>
            <input type="file" name="gambar" id="gambar" accept="image/*">
        </form>
        <button form="login" name="submit">Edit</button>
    </div>
</body>
</html>