<?php

    include '../config.php';
    $db = new Dbh();
    $conn = $db->connect();
    $error = "";

    if (isset($_POST["submit"])) {
        extract($_POST);

        $target_dir = "../uploads/";
        $prefix_file = time() . "-";
        $file_name = $prefix_file . basename($_FILES["gambar"]["name"]);
        $target_file = $target_dir . $file_name;
        $success = move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file);

        if ($success) {
            $sql = "INSERT INTO produk (title, description, price, idKategori, images) VALUES ('$title', '$description', $price, $kategori, '$file_name')";
            $result = $conn->query($sql);
    
            if ($result) {
                header("Location: ../produk.php");
            } else {
                $error = "Gagal menambah produk";
            }
        } else {
            $error = "Gagal menambah produk";
        }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop App</title>
    <link rel="stylesheet" href="../css/general.css">
    <link rel="stylesheet" href="../css/actions.css">
    <link rel="shortcut icon" href="../assets/logo.png" type="image/x-icon">
</head>
<body>
    <!-- nampilkan eror -->
    <p id="error"><?= $error ?></p>

    <!-- kotak hijau  -->
    <div id="container">

        <!-- judul halaman yy -->
        <h1>Create Product</h1>
        <form id="login" action="" method="post" enctype="multipart/form-data">
            <input type="text" name="title" placeholder="Title" required>
            <textarea name="description" id="description" placeholder="Description" rows="5" required></textarea>
            <input type="number" name="price" placeholder="Price" min="1000" step="1000" required>
            <select name="kategori" id="kategori" required>
                <option value="">--- Pilih Kategori ---</option>
                <?php
                
                $sql = "SELECT * FROM kategori";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    ?>
                    
                    <option value="<?= $row["id"] ?>"><?= $row["nama"] ?></option>
                    
                    <?php
                }
                
                ?>
            </select>
            <label for="gambar">Pilih gambar:</label>
            <input type="file" name="gambar" id="gambar" accept="image/*" required>
        </form>
        <button form="login" name="submit">Create</button>
    </div>
</body>
</html>